<?php 

	if( is_active_sidebar( 'az_sidebar' ) ){
		dynamic_sidebar( 'az_sidebar' );
	}

?>